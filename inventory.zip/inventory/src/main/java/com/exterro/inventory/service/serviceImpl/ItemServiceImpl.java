/**
 * 
 */
package com.exterro.inventory.service.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.exterro.inventory.entity.Items;
import com.exterro.inventory.repository.ItemsRepo;
import com.exterro.inventory.service.IItemService;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Service
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class ItemServiceImpl  implements IItemService{
	
	@Autowired
	private ItemsRepo itemsRepository;
	@Override
	public List<Items> getAllItems() {
		return itemsRepository.findAll();
	}

	@Override
	public Items getItemById(int itemId) {
		Optional<Items> item = itemsRepository.findById(itemId);
		return item.get();
	}

	@Override
	public ResponseEntity<String> saveItems(List<Items> items) {
		 List<Items> insertedItems =itemsRepository.saveAll(items);
		if(insertedItems != null && !insertedItems.isEmpty()) 
			return new ResponseEntity<String>("Success",HttpStatus.CREATED);
		else
			return new ResponseEntity<String>("Failure",HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> updateItem(Items item) {
		Items updatedItem =  itemsRepository.save(item);
		if(updatedItem != null) 
			return new ResponseEntity<String>("Success",HttpStatus.OK);
		else
			return new ResponseEntity<String>("Failure",HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> deleteItem(int itemId) {
		itemsRepository.deleteById(itemId);
		return new ResponseEntity<String>("Success",HttpStatus.OK);
	}
	
}
