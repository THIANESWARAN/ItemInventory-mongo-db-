/**
 * 
 */
package com.exterro.inventory.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.exterro.inventory.entity.Items;

/**
 * 
 */
public interface ItemsRepo extends MongoRepository<Items, Integer>{
	

}
