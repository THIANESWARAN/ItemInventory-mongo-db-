package com.exterro.inventory.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.exterro.inventory.entity.Items;


@Component
public interface IItemService {
	List<Items> getAllItems();
	
	
	Items getItemById(int itemId);
	
	ResponseEntity<String> saveItems(List<Items> items);
	
	ResponseEntity<String> updateItem(Items item);
	
	ResponseEntity<String> deleteItem(int itemId);
}
