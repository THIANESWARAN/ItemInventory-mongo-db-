/**
 * 
 */
package com.exterro.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exterro.inventory.entity.ErrorResponse;
import com.exterro.inventory.entity.Items;
import com.exterro.inventory.service.IItemService;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@RestController
@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor
public class ItemController {
	
	@Autowired
	private IItemService itemService;
	
	
	public static final String ITEMID_VALIDATION_MESSAGE = "Item Id Cannot be Less than or Equal to Zero";
	
	public static final String ITEM_VALIDATION_MESSAGE = "Item (or) Item list cannot be empty";
	
	@GetMapping("/get/items")
	public ResponseEntity<?> getAllItems(){
		try {
			List<Items> itemList = itemService.getAllItems();
			return new ResponseEntity<>(itemList,HttpStatus.OK);
		}catch (Exception e) {
			log.error("Exception in getAllItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/get/items/{itemId}")
	public ResponseEntity<?> getAllItems(@PathVariable Integer itemId){
		try {
			if(itemId <= 0) {
				return new ResponseEntity<>(ITEMID_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);
			}
			Items item = itemService.getItemById(itemId);
			return new ResponseEntity<>(item,HttpStatus.OK);
		}catch (Exception e) {
			log.error("Exception in getAllItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/save/items")
	public ResponseEntity<?> saveItems(@RequestBody List<Items> itemList){
		try {
			if(itemList != null && !itemList.isEmpty()) {
				return itemService.saveItems(itemList);	
			}else {
				return new ResponseEntity<>(ITEM_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);	
			}
		}catch (Exception e) {
			log.error("Exception in getAllItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/update/item")
	public ResponseEntity<?> updateItem(@RequestBody Items item){
		try {
			if(item == null) {
				return new ResponseEntity<>(ITEM_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);	
			}
			return itemService.updateItem(item);	
		}catch (Exception e) {
			log.error("Error in updateItem -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping("/delete/item/{itemId}")
	public ResponseEntity<?> deleteItem(@PathVariable Integer itemId){
		try {
			if(itemId <= 0) {
				return new ResponseEntity<>(ITEMID_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);
			}
			return itemService.deleteItem(itemId);	
		} catch (Exception e) {
			log.error("Error in deleteItem -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}

}
